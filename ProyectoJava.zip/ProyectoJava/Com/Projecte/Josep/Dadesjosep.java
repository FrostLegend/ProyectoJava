package Com.Projecte.Josep;

public class Dadesjosep {
    public static void mostrarNom() {
        System.out.println("Capitan General: Josep");
    }
}
