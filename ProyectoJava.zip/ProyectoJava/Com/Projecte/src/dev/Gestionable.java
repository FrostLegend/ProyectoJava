package Com.Projecte.src.dev;

public interface Gestionable {
    public String getIdentificador();

    public String resum();

    public void mostrarDetalls();

}
