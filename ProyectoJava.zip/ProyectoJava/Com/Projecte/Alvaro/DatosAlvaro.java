package Com.Projecte.Alvaro;

public class DatosAlvaro {
    private static String nombre = "Alvaro";

    public static void mostrarNombre() {
        System.out.println("Responsable BBDD de Java: (Caido en combate)" + nombre);
    }
}