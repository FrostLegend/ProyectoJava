package Com.Projecte.Alejandro;
public class DatosAlejandro {
    private static String nombre = "Alejandro";

    public static void mostrarNombre() {
        System.out.println("Encargado GitHub: " + nombre);
    }
}
