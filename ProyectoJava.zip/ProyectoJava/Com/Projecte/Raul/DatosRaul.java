package Com.Projecte.Raul;

public class DatosRaul {
    public static void mostrarNombre() {
        System.out.println("Soporte Auxiliar: Raul");
    }
}
