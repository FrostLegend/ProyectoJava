package Com.Projecte.Main;
import Com.Projecte.Josep.Dadesjosep;
public class ProgramaPrincipal {
    public static void main(String[] args) {
        inici();
    }

    public static void inici() {
        Dadesjosep.mostrarNom();
    }
}